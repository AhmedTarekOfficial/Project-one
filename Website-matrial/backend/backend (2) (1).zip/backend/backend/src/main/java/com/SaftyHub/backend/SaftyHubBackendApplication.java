package com.SaftyHub.backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SaftyHubBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(SaftyHubBackendApplication.class, args);
	}

}
