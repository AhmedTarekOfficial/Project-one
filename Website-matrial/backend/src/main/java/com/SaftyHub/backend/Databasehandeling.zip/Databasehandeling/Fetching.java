package main.java.com.SaftyHub.backend.Databasehandeling ;
import jakarta.persistence.* ;

public class Fetching extends Database_common_components {

    @PersistenceContext
    private EntityManager entityManager;


public String Querybuilder(){

    return "" ;
}


    public String Searching_information(
String tablename  , String [] table_columns , 
String [] searching_conditions , 
String [] conditions_values 
    ) 
    {
        
        

        return "" ;
    }

}
