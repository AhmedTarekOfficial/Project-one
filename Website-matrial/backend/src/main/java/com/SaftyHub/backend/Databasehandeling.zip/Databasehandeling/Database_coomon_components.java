package main.java.com.SaftyHub.backend.Databasehandeling ;

public  class Database_coomon_components {


public String validate_value(String value) {

    return "" ;
}
    
}
