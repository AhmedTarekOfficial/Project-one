package main.java.com.SaftyHub.backend.Databasehandeling;
public class Insert extends Database_common_components {


public String querybuilder(String tablename , String [] values 
, String [] columnsconditions
){

    return "" ;
}

@Overload 
public validate_value(String value) {

    return "" ;
}


public void put_Data(String tablename , String [] values  , String [] columnsconditions) {

}

    
}
