package main.java.com.SaftyHub.backend.Databasehandeling;
public class Enhancement {


public String Querybuilder(String tablename ,
String [] updated_columns , String [] updated_columns_values , String [] conditions
){
    StringBuilder Query = new StringBuilder("update") ;
    return "" ;
}

    public void Updateinformation(
String tablename , String [] Updated_columns , 
String [] Updated_columns_values , String [] conditions
    ){

    }
    
}
